/*
 * DigitalIoPin.h
 *
 *  Created on: 31 Aug 2022
 *      Author: Daniil Marinec
 */

#ifndef DIGITALIOPIN_H_
#define DIGITALIOPIN_H_

#include "chip.h"
#include "board.h"

class DigitalIoPin {
public:
	DigitalIoPin(int port, int pin, bool input = true, bool pullup = true, bool invert = false);
	DigitalIoPin(const DigitalIoPin &) = delete;
	virtual ~DigitalIoPin();
	bool read();
	void write(bool value);
private:
	int port;
	int pin;
	bool input;
};

#endif /* DIGITALIOPIN_H_ */
